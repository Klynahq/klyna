# Aurora by Klyna

**Minimal. Fast. Conversion-first.**

Aurora is a Shopify Online Store 2.0 theme built by Klyna for brands that refuse to compromise on design or speed. Think Apple.com-clean, DTC-ready, dark by default.

---

## What makes Aurora convert

| Feature | Detail |
|---|---|
| Sticky buy bar | Appears on scroll, disappears when the main CTA is in view. Increases add-to-cart rates. |
| Trust badges row | Free returns · Secure payment · Fast shipping — directly below the buy button. |
| Hover second image | Product cards swap to a lifestyle shot on hover. Zero JavaScript weight. Pure CSS. |
| Quick-add | One-click add for single-variant products. Multi-variant opens the PDP. |
| Cart drawer | Slide-in cart with subtotal, product thumbnails, and checkout CTA. No page reload. |
| AJAX filters | Collection filters update the grid without a full page load. |
| Zero layout shift | All images have aspect-ratio locked containers. No CLS. |
| Lazy loading | All below-fold images use `loading="lazy"`. |
| Print stylesheet | Built-in print styles strip navigation, animations, and backgrounds. |

---

## Previewing locally

### Prerequisites
- [Shopify CLI](https://shopify.dev/docs/themes/tools/cli) v3+
- A Shopify Partner account + development store

### Steps

```bash
# From the theme root (where this README lives):
shopify theme dev --store=your-store.myshopify.com

# To push to a specific theme:
shopify theme push --store=your-store.myshopify.com
```

The CLI will print a preview URL. Open it in your browser to see the theme with live editing support.

---

## Theme structure

```
aurora/
├── assets/          CSS, JS, SVG
├── config/          settings_schema.json + settings_data.json
├── layout/          theme.liquid, password.liquid
├── locales/         en.default.json, en.default.schema.json
├── sections/        All sections (each has a {% schema %})
├── snippets/        Reusable partials
└── templates/       JSON templates (OS 2.0)
```

---

## Customisation

All settings live in the theme editor (`Customize` → your store admin):

- **Colors** — background, surface, accent, text, buttons. Three presets included (Dark, Light, Midnight).
- **Typography** — font pickers for heading and body. Defaults to Inter.
- **Layout** — page width (1000–1600px), section vertical spacing.
- **Product cards** — toggle vendor, quick-add, star rating.
- **Cart** — drawer vs. page, order notes.

---

## Sections reference

| Section | Description |
|---|---|
| `announcement-bar` | Dismissible top banner with link support |
| `header` | Sticky nav, logo, search, cart, mobile hamburger |
| `footer` | Multi-column links, newsletter, social icons, payment icons |
| `image-banner` | Full-bleed hero, 4 heights, overlay, up to 2 CTAs |
| `featured-collection` | Configurable product grid with 'View all' |
| `rich-text` | Editorial centred text section |
| `image-with-text` | 50/50 split, image position configurable |
| `multicolumn` | 2–4 icon/image + text columns |
| `newsletter` | Email capture (compatible with Klaviyo / Mailchimp form redirect) |
| `testimonials` | Star-rated quote cards |
| `collapsible-content` | FAQ accordion |
| `main-product` | PDP with gallery, variant picker, sticky buy bar, trust badges |
| `main-collection-product-grid` | Filter + sort + paginated product grid |
| `collection-banner` | Collection image hero or plain header |
| `main-cart-items` + `main-cart-footer` | Full cart page |
| `main-page` | Generic page with optional contact form |
| `main-blog` | Blog index grid |
| `main-article` | Article with share buttons, prev/next |
| `main-search` | Search form + results grid |
| `main-404` | Friendly 404 page |
| `main-list-collections` | Collections grid |
| Customer sections | Account, login, register, order, addresses, reset/activate password |

---

## STATUS

| Area | Status |
|---|---|
| All templates | Complete |
| All sections | Complete |
| Snippets | Complete |
| CSS design system | Complete |
| JavaScript (AJAX cart, variants, gallery, filters) | Complete |
| Locales (en) | Complete |
| Settings schema + data | Complete |
| Structured data / OG tags | Complete |
| Theme check compliance | Ready for review |

**Not included (add via Shopify apps):**
- Ratings & reviews (Okendo, Judge.me, etc.) — review block renders the `#shopify-product-reviews` mount point
- Back-in-stock notifications
- Wishlist
- Subscription (ReCharge, etc.)
