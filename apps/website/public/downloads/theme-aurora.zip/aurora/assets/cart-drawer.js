/**
 * Aurora by Klyna — cart-drawer.js
 * Extended cart drawer utilities.
 * Core logic lives in global.js; this file handles
 * drawer-specific enhancements (line item rendering, upsell hooks).
 */

(function () {
  'use strict';

  // Expose Aurora config object for string overrides set in theme.liquid
  window.Aurora = window.Aurora || {};
  window.Aurora.strings = window.Aurora.strings || {
    cart_empty: 'Your cart is empty.',
    subtotal: 'Subtotal',
    taxes_shipping: 'Taxes and shipping calculated at checkout.',
    checkout: 'Check Out',
    view_cart: 'View Cart',
    add_to_cart: 'Add to Cart',
    sold_out: 'Sold Out',
    adding: 'Adding…',
  };

  // Currency from meta tag if available
  const currencyMeta = document.querySelector('meta[name="currency"]');
  if (currencyMeta) window.Aurora.currency = currencyMeta.content;

})();
