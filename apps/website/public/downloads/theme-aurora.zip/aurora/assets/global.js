/**
 * Aurora by Klyna — global.js
 * Vanilla JS, no jQuery. Handles:
 *  - Cart AJAX (add / update / remove)
 *  - Variant selection + URL update
 *  - Mobile menu
 *  - Sticky header scroll behaviour
 *  - Search modal
 *  - Announcement bar close
 *  - Back-to-top button
 *  - Quantity inputs
 *  - Quick-add buttons
 */

(function () {
  'use strict';

  /* -----------------------------------------------------------------------
     Utility helpers
  ----------------------------------------------------------------------- */

  /**
   * Debounce a function call.
   */
  function debounce(fn, wait = 200) {
    let timer;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), wait);
    };
  }

  /**
   * Trap focus within a container.
   */
  function trapFocus(container, focusTarget) {
    const focusable = container.querySelectorAll(
      'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    );
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (focusTarget) focusTarget.focus();
    container._trapHandler = (e) => {
      if (e.key !== 'Tab') return;
      if (e.shiftKey) {
        if (document.activeElement === first) { e.preventDefault(); last.focus(); }
      } else {
        if (document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    container.addEventListener('keydown', container._trapHandler);
  }

  function removeFocusTrap(container) {
    if (container._trapHandler) {
      container.removeEventListener('keydown', container._trapHandler);
      delete container._trapHandler;
    }
  }

  /* -----------------------------------------------------------------------
     Cart API
  ----------------------------------------------------------------------- */

  const CartAPI = {
    _fetch(url, body) {
      return fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(body),
      }).then((res) => {
        if (!res.ok) throw new Error(`Cart API error: ${res.status}`);
        return res.json();
      });
    },

    getCart() {
      return fetch('/cart.js', { headers: { Accept: 'application/json' } }).then((r) => r.json());
    },

    addItem(variantId, quantity = 1, properties = {}) {
      return this._fetch('/cart/add.js', { id: variantId, quantity, properties });
    },

    updateItem(key, quantity) {
      return this._fetch('/cart/change.js', { id: key, quantity });
    },

    removeItem(key) {
      return this._fetch('/cart/change.js', { id: key, quantity: 0 });
    },
  };

  /* -----------------------------------------------------------------------
     Cart drawer
  ----------------------------------------------------------------------- */

  const CartDrawer = {
    drawer: null,
    body: null,
    footer: null,

    init() {
      this.drawer = document.getElementById('CartDrawer');
      if (!this.drawer) return;
      this.body = document.getElementById('CartDrawerBody');
      this.footer = document.getElementById('CartDrawerFooter');

      document.addEventListener('click', (e) => {
        if (e.target.closest('[data-cart-drawer-open]')) {
          e.preventDefault();
          this.open();
        }
        if (e.target.closest('[data-cart-drawer-close]') || e.target === this.drawer.querySelector('[data-cart-drawer-overlay]')) {
          this.close();
        }
      });

      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && this.drawer.getAttribute('aria-hidden') === 'false') this.close();
      });
    },

    open() {
      this.refresh().then(() => {
        this.drawer.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
        trapFocus(this.drawer);
      });
    },

    close() {
      this.drawer.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
      removeFocusTrap(this.drawer);
    },

    async refresh() {
      const cart = await CartAPI.getCart();
      this.renderBody(cart);
      this.renderFooter(cart);
      this.updateHeaderCount(cart.item_count);
    },

    renderBody(cart) {
      if (!this.body) return;
      if (cart.item_count === 0) {
        this.body.innerHTML = `<p class="cart-drawer__empty" style="padding:2rem;text-align:center;color:var(--color-text-muted)">${window.Aurora?.strings?.cart_empty || 'Your cart is empty.'}</p>`;
        return;
      }
      const items = cart.items.map((item) => `
        <div class="cart-drawer-item" data-key="${item.key}">
          <a href="${item.url}">
            <img src="${item.image}" alt="${item.product_title}" width="64" height="64" style="width:64px;height:64px;object-fit:cover;border-radius:8px">
          </a>
          <div style="flex:1;min-width:0">
            <p style="font-weight:600;font-size:0.875rem">${item.product_title}</p>
            ${item.variant_title && item.variant_title !== 'Default Title' ? `<p style="font-size:0.75rem;color:var(--color-text-muted)">${item.variant_title}</p>` : ''}
            <p style="font-size:0.875rem;margin-top:0.25rem">${formatMoney(item.final_line_price)}</p>
          </div>
          <button
            class="icon-btn"
            data-drawer-remove="${item.key}"
            aria-label="Remove ${item.product_title}"
            style="align-self:flex-start;color:var(--color-text-muted)"
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
      `).join('');
      this.body.innerHTML = `<div style="display:flex;flex-direction:column;gap:1rem">${items}</div>`;

      this.body.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-drawer-remove]');
        if (!btn) return;
        CartAPI.removeItem(btn.dataset.drawerRemove).then(() => this.refresh());
      });
    },

    renderFooter(cart) {
      if (!this.footer) return;
      if (cart.item_count === 0) { this.footer.innerHTML = ''; return; }
      this.footer.innerHTML = `
        <div style="margin-bottom:0.875rem">
          <div style="display:flex;justify-content:space-between;font-weight:700;font-size:1.125rem;margin-bottom:0.25rem">
            <span>${window.Aurora?.strings?.subtotal || 'Subtotal'}</span>
            <span>${formatMoney(cart.total_price)}</span>
          </div>
          <p style="font-size:0.75rem;color:var(--color-text-muted)">${window.Aurora?.strings?.taxes_shipping || 'Taxes and shipping calculated at checkout'}</p>
        </div>
        <a href="/checkout" class="btn btn--primary btn--full">${window.Aurora?.strings?.checkout || 'Checkout'}</a>
        <a href="/cart" class="btn btn--ghost btn--full" style="margin-top:0.5rem">${window.Aurora?.strings?.view_cart || 'View Cart'}</a>
      `;
    },

    updateHeaderCount(count) {
      const counters = document.querySelectorAll('.header__cart-count');
      counters.forEach((el) => {
        el.textContent = count;
        el.hidden = count === 0;
      });
    },
  };

  /* -----------------------------------------------------------------------
     Format money helper (Shopify uses cents)
  ----------------------------------------------------------------------- */
  function formatMoney(cents) {
    const amount = (cents / 100).toFixed(2);
    const currency = window.Aurora?.currency || 'USD';
    try {
      return new Intl.NumberFormat(navigator.language, { style: 'currency', currency }).format(amount);
    } catch {
      return `$${amount}`;
    }
  }

  /* -----------------------------------------------------------------------
     Variant selection
  ----------------------------------------------------------------------- */

  const VariantPicker = {
    init() {
      document.querySelectorAll('[data-variant-option-radio]').forEach((input) => {
        input.addEventListener('change', (e) => this.handleChange(e));
      });
      document.querySelectorAll('[data-variant-option-select]').forEach((select) => {
        select.addEventListener('change', (e) => this.handleChange(e));
      });
    },

    handleChange(e) {
      const fieldset = e.target.closest('[data-option-index]');
      if (!fieldset) return;
      const sectionId = e.target.closest('[id^="VariantPicker-"]')?.id.replace('VariantPicker-', '');
      if (!sectionId) return;

      // Update selected label
      const legend = fieldset.querySelector('.variant-picker__selected');
      if (legend) legend.textContent = e.target.value;

      // Update active state for button/swatch styles
      fieldset.querySelectorAll('.btn-option, .swatch-option').forEach((el) => {
        const input = el.querySelector('input') || el;
        const isSelected = input.value === e.target.value;
        el.classList.toggle('btn-option--selected', isSelected);
        el.classList.toggle('swatch-option--selected', isSelected);
      });

      this.updateVariant(sectionId);
    },

    getSelectedOptions(sectionId) {
      const container = document.getElementById(`VariantPicker-${sectionId}`);
      if (!container) return [];
      const options = [];
      container.querySelectorAll('[data-option-index]').forEach((fieldset) => {
        const checked = fieldset.querySelector('[data-variant-option-radio]:checked') ||
          fieldset.querySelector('[data-variant-option-select]');
        if (checked) options.push(checked.value);
      });
      return options;
    },

    getVariants(sectionId) {
      try {
        const el = document.getElementById(`ProductVariants-${sectionId}`);
        return el ? JSON.parse(el.textContent) : [];
      } catch { return []; }
    },

    findVariant(options, variants) {
      return variants.find((v) =>
        v.options.every((opt, i) => opt === options[i])
      ) || null;
    },

    updateVariant(sectionId) {
      const options = this.getSelectedOptions(sectionId);
      const variants = this.getVariants(sectionId);
      const variant = this.findVariant(options, variants);
      if (!variant) return;

      // Update URL
      const url = new URL(window.location.href);
      url.searchParams.set('variant', variant.id);
      window.history.replaceState({}, '', url.toString());

      // Update hidden input
      const form = document.querySelector(`[data-type="add-to-cart-form"] input[name="id"]`);
      if (form) form.value = variant.id;

      // Update price
      this.updatePrice(sectionId, variant);

      // Update add-to-cart button state
      const addBtn = document.querySelector('.product__add-to-cart');
      const stickyBtn = document.querySelector('[data-sticky-buy-btn]');
      const btns = [addBtn, stickyBtn].filter(Boolean);

      const available = variant.available;
      const btnText = available
        ? (window.Aurora?.strings?.add_to_cart || 'Add to Cart')
        : (window.Aurora?.strings?.sold_out || 'Sold Out');

      btns.forEach((btn) => {
        btn.disabled = !available;
        const textSpan = btn.querySelector('.btn-text') || btn;
        if (btn.querySelector('.btn-text')) {
          textSpan.textContent = btnText;
        } else {
          btn.textContent = btnText;
        }
      });

      // Update gallery to match variant image
      if (variant.featured_image) {
        const gallerySlides = document.querySelectorAll('.product-gallery__slide');
        gallerySlides.forEach((slide) => {
          const img = slide.querySelector('img');
          if (img && img.src.includes(variant.featured_image.src.split('?')[0].split('/').pop().split('.')[0])) {
            gallerySlides.forEach((s) => s.classList.remove('product-gallery__slide--active'));
            slide.classList.add('product-gallery__slide--active');
          }
        });
      }
    },

    updatePrice(sectionId, variant) {
      const priceWrapper = document.getElementById(`price-${sectionId}`);
      if (!priceWrapper) return;
      const price = formatMoney(variant.price);
      const compareAt = variant.compare_at_price;
      let html = '';
      if (compareAt && compareAt > variant.price) {
        html = `<div class="price price--on-sale">
          <span class="price__regular"><span class="price__amount">${price}</span></span>
          <span class="price__compare"><s class="price__amount price__amount--compare">${formatMoney(compareAt)}</s></span>
        </div>`;
      } else {
        html = `<div class="price"><span class="price__regular"><span class="price__amount">${price}</span></span></div>`;
      }
      priceWrapper.innerHTML = html;

      // Also update sticky bar price
      const stickyPrice = document.querySelector('.sticky-buy-bar__price');
      if (stickyPrice) stickyPrice.innerHTML = `<span class="price__amount">${price}</span>`;
    },
  };

  /* -----------------------------------------------------------------------
     Add to cart form
  ----------------------------------------------------------------------- */

  function initAddToCartForm() {
    document.addEventListener('submit', async (e) => {
      const form = e.target;
      if (!form.matches('[data-type="add-to-cart-form"]')) return;
      e.preventDefault();

      const btn = form.querySelector('.product__add-to-cart');
      if (!btn || btn.disabled) return;

      const variantId = form.querySelector('[name="id"]')?.value;
      const quantity = parseInt(form.querySelector('[name="quantity"]')?.value || '1', 10);
      if (!variantId) return;

      // Loading state
      btn.disabled = true;
      const btnText = btn.querySelector('.btn-text');
      const btnLoader = btn.querySelector('.btn-loader');
      if (btnText) btnText.hidden = true;
      if (btnLoader) btnLoader.hidden = false;

      try {
        await CartAPI.addItem(variantId, quantity);
        await CartDrawer.refresh();
        CartDrawer.open();
      } catch (err) {
        console.error('Add to cart failed:', err);
      } finally {
        btn.disabled = false;
        if (btnText) { btnText.hidden = false; }
        if (btnLoader) { btnLoader.hidden = true; }
      }
    });
  }

  /* -----------------------------------------------------------------------
     Quick add
  ----------------------------------------------------------------------- */

  function initQuickAdd() {
    document.addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-quick-add]');
      if (!btn) return;
      const variantId = btn.dataset.variantId;
      if (!variantId) return;
      btn.disabled = true;
      btn.textContent = window.Aurora?.strings?.adding || 'Adding…';
      try {
        await CartAPI.addItem(variantId);
        await CartDrawer.refresh();
        CartDrawer.open();
      } catch (err) {
        console.error('Quick add failed:', err);
      } finally {
        btn.disabled = false;
        btn.textContent = window.Aurora?.strings?.add_to_cart || 'Add to Cart';
      }
    });
  }

  /* -----------------------------------------------------------------------
     Cart quantity controls (cart page)
  ----------------------------------------------------------------------- */

  function initCartQuantity() {
    document.addEventListener('click', async (e) => {
      const minusBtn = e.target.closest('[data-cart-quantity-minus]');
      const plusBtn = e.target.closest('[data-cart-quantity-plus]');
      const removeBtn = e.target.closest('[data-cart-remove]');

      if (minusBtn || plusBtn) {
        const btn = minusBtn || plusBtn;
        const key = btn.dataset.key;
        const qty = parseInt(btn.dataset.quantity, 10);
        if (!key) return;
        await CartAPI.updateItem(key, Math.max(0, qty));
        window.location.reload();
      }

      if (removeBtn) {
        const key = removeBtn.dataset.key;
        await CartAPI.removeItem(key);
        window.location.reload();
      }
    });

    document.querySelectorAll('[data-cart-quantity-input]').forEach((input) => {
      input.addEventListener('change', debounce(async (e) => {
        const key = e.target.dataset.key;
        const qty = parseInt(e.target.value, 10);
        if (!key || isNaN(qty)) return;
        await CartAPI.updateItem(key, qty);
        window.location.reload();
      }, 600));
    });
  }

  /* -----------------------------------------------------------------------
     Quantity selector (PDP)
  ----------------------------------------------------------------------- */

  function initQuantitySelector() {
    document.addEventListener('click', (e) => {
      const minus = e.target.closest('[data-quantity-minus]');
      const plus = e.target.closest('[data-quantity-plus]');
      if (!minus && !plus) return;

      const wrapper = (minus || plus).closest('.quantity-wrapper');
      if (!wrapper) return;
      const input = wrapper.querySelector('.quantity-input');
      if (!input) return;

      let val = parseInt(input.value, 10) || 1;
      if (minus) val = Math.max(parseInt(input.min, 10) || 1, val - 1);
      if (plus) val = val + 1;
      input.value = val;
    });
  }

  /* -----------------------------------------------------------------------
     Sticky header
  ----------------------------------------------------------------------- */

  function initStickyHeader() {
    const header = document.getElementById('SiteHeader');
    if (!header) return;
    const onScroll = () => {
      header.classList.toggle('header--scrolled', window.scrollY > 10);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* -----------------------------------------------------------------------
     Sticky buy bar
  ----------------------------------------------------------------------- */

  function initStickyBuyBar() {
    const bar = document.getElementById('StickyBuyBar');
    if (!bar) return;
    const buyButtons = document.querySelector('.product__buy-buttons');
    if (!buyButtons) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        const show = !entry.isIntersecting;
        bar.setAttribute('aria-hidden', show ? 'false' : 'true');
      },
      { threshold: 0 }
    );

    observer.observe(buyButtons);

    // Sticky btn → scroll to form or submit
    bar.querySelector('[data-sticky-buy-btn]')?.addEventListener('click', () => {
      buyButtons.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  }

  /* -----------------------------------------------------------------------
     Mobile menu
  ----------------------------------------------------------------------- */

  function initMobileMenu() {
    const menu = document.getElementById('MobileMenu');
    if (!menu) return;
    const openBtns = document.querySelectorAll('[data-mobile-menu-open]');
    const closeBtns = document.querySelectorAll('[data-mobile-menu-close]');

    function open() {
      menu.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
      openBtns.forEach((b) => b.setAttribute('aria-expanded', 'true'));
      trapFocus(menu);
    }

    function close() {
      menu.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
      openBtns.forEach((b) => b.setAttribute('aria-expanded', 'false'));
      removeFocusTrap(menu);
    }

    openBtns.forEach((b) => b.addEventListener('click', open));
    closeBtns.forEach((b) => b.addEventListener('click', close));
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && menu.getAttribute('aria-hidden') === 'false') close();
    });
  }

  /* -----------------------------------------------------------------------
     Search modal
  ----------------------------------------------------------------------- */

  function initSearchModal() {
    const modal = document.getElementById('SearchModal');
    if (!modal) return;
    const openBtns = document.querySelectorAll('[data-search-modal-open]');
    const closeBtns = document.querySelectorAll('[data-search-modal-close]');
    const overlay = modal.querySelector('[data-search-modal-overlay]');

    function open() {
      modal.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
      const input = modal.querySelector('.search-modal__input');
      if (input) setTimeout(() => input.focus(), 50);
    }

    function close() {
      modal.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }

    openBtns.forEach((b) => b.addEventListener('click', open));
    closeBtns.forEach((b) => b.addEventListener('click', close));
    if (overlay) overlay.addEventListener('click', close);
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal.getAttribute('aria-hidden') === 'false') close();
    });
  }

  /* -----------------------------------------------------------------------
     Announcement bar
  ----------------------------------------------------------------------- */

  function initAnnouncementBar() {
    const bar = document.getElementById('AnnouncementBar');
    if (!bar) return;
    if (sessionStorage.getItem('aurora-announcement-closed')) { bar.hidden = true; return; }
    const closeBtn = bar.querySelector('[data-announcement-bar-close]');
    if (!closeBtn) return;
    closeBtn.addEventListener('click', () => {
      bar.style.maxHeight = bar.offsetHeight + 'px';
      requestAnimationFrame(() => {
        bar.style.transition = 'max-height 0.3s ease, opacity 0.3s ease';
        bar.style.maxHeight = '0';
        bar.style.opacity = '0';
        bar.style.overflow = 'hidden';
      });
      bar.addEventListener('transitionend', () => { bar.hidden = true; }, { once: true });
      sessionStorage.setItem('aurora-announcement-closed', '1');
    });
  }

  /* -----------------------------------------------------------------------
     Back to top
  ----------------------------------------------------------------------- */

  function initBackToTop() {
    const btn = document.getElementById('BackToTop');
    if (!btn) return;
    window.addEventListener('scroll', debounce(() => {
      btn.hidden = window.scrollY < 400;
    }, 100), { passive: true });
    btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  /* -----------------------------------------------------------------------
     Init all
  ----------------------------------------------------------------------- */

  function init() {
    CartDrawer.init();
    VariantPicker.init();
    initAddToCartForm();
    initQuickAdd();
    initCartQuantity();
    initQuantitySelector();
    initStickyHeader();
    initStickyBuyBar();
    initMobileMenu();
    initSearchModal();
    initAnnouncementBar();
    initBackToTop();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
