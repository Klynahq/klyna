/**
 * Aurora by Klyna — filters.js
 * Collection page: filter group toggle, AJAX filter submit + sort.
 */

(function () {
  'use strict';

  const SELECTOR_GRID = '#ProductGrid';
  const SELECTOR_SORT = '[data-sort-select]';
  const SELECTOR_FILTER_CLEAR = '[data-filters-clear]';
  const SELECTOR_FILTER_INPUT = '.collection-grid__filters input, .collection-grid__filters select';
  const SELECTOR_FILTER_TOGGLE = '.filter-group__toggle';

  function getFilterUrl() {
    const form = document.querySelector('.collection-grid__filters');
    if (!form) return null;
    const params = new URLSearchParams(window.location.search);
    // Clear filter params
    [...params.keys()].forEach((k) => {
      if (k.startsWith('filter.') || k === 'sort_by') params.delete(k);
    });
    // Rebuild from inputs
    form.querySelectorAll('input[type="checkbox"]:checked').forEach((el) => {
      params.append(el.name, el.value);
    });
    form.querySelectorAll('input[type="number"]').forEach((el) => {
      if (el.value !== '') params.set(el.name, el.value);
    });
    return params;
  }

  async function applyFilters(extraParams = null) {
    const params = extraParams || getFilterUrl();
    if (!params) return;

    const url = `${window.location.pathname}?${params.toString()}&section_id=main-collection-product-grid`;

    try {
      const res = await fetch(url, { headers: { Accept: 'text/html' } });
      const html = await res.text();
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, 'text/html');
      const newGrid = doc.querySelector(SELECTOR_GRID);
      const currentGrid = document.querySelector(SELECTOR_GRID);
      if (newGrid && currentGrid) {
        currentGrid.innerHTML = newGrid.innerHTML;
      }
      // Update count
      const newCount = doc.querySelector('.collection-grid__count');
      const currentCount = document.querySelector('.collection-grid__count');
      if (newCount && currentCount) currentCount.textContent = newCount.textContent;

      // Update URL without reload
      const cleanUrl = `${window.location.pathname}?${params.toString().replace(/&?section_id=[\w-]+/, '')}`;
      window.history.replaceState({}, '', cleanUrl);
    } catch (err) {
      console.error('Filter fetch failed:', err);
    }
  }

  function initFilterToggles() {
    document.querySelectorAll(SELECTOR_FILTER_TOGGLE).forEach((btn) => {
      const content = document.getElementById(btn.getAttribute('aria-controls'));
      if (!content) return;
      btn.addEventListener('click', () => {
        const isExpanded = btn.getAttribute('aria-expanded') === 'true';
        btn.setAttribute('aria-expanded', isExpanded ? 'false' : 'true');
        content.hidden = isExpanded;
      });
    });
  }

  function initFilterInputs() {
    document.querySelectorAll(SELECTOR_FILTER_INPUT).forEach((input) => {
      input.addEventListener('change', () => applyFilters());
    });
  }

  function initSortSelect() {
    const select = document.querySelector(SELECTOR_SORT);
    if (!select) return;
    select.addEventListener('change', () => {
      const params = new URLSearchParams(window.location.search);
      params.set('sort_by', select.value);
      applyFilters(params);
    });
  }

  function initClearFilters() {
    const btn = document.querySelector(SELECTOR_FILTER_CLEAR);
    if (!btn) return;
    btn.addEventListener('click', () => {
      document.querySelectorAll('.collection-grid__filters input[type="checkbox"]').forEach((el) => {
        el.checked = false;
      });
      document.querySelectorAll('.collection-grid__filters input[type="number"]').forEach((el) => {
        el.value = '';
      });
      applyFilters();
    });
  }

  function init() {
    if (!document.querySelector('.collection-grid')) return;
    initFilterToggles();
    initFilterInputs();
    initSortSelect();
    initClearFilters();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
