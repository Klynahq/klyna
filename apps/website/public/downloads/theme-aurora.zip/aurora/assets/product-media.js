/**
 * Aurora by Klyna — product-media.js
 * Gallery: thumbnail click, zoom on hover (desktop), lightbox open/close,
 * touch swipe on mobile.
 */

(function () {
  'use strict';

  /* -----------------------------------------------------------------------
     Gallery
  ----------------------------------------------------------------------- */

  function initGallery(galleryEl) {
    const sectionId = galleryEl.id.replace('ProductGallery-', '');
    const mainEl = document.getElementById(`ProductGalleryMain-${sectionId}`);
    const thumbsEl = document.getElementById(`ProductGalleryThumbs-${sectionId}`);
    const lightboxEl = document.getElementById(`GalleryLightbox-${sectionId}`);
    const lightboxContent = document.getElementById(`GalleryLightboxContent-${sectionId}`);

    if (!mainEl) return;

    const slides = Array.from(mainEl.querySelectorAll('.product-gallery__slide'));
    const thumbs = thumbsEl ? Array.from(thumbsEl.querySelectorAll('.product-gallery__thumb')) : [];

    let currentIndex = 0;
    let touchStartX = 0;
    let touchEndX = 0;

    // ---- Slide activation ----
    function goTo(index) {
      if (index < 0) index = slides.length - 1;
      if (index >= slides.length) index = 0;

      const prev = slides[currentIndex];
      const next = slides[index];

      prev.classList.remove('product-gallery__slide--active');
      next.classList.add('product-gallery__slide--active');

      thumbs.forEach((t, i) => {
        t.classList.toggle('product-gallery__thumb--active', i === index);
        t.setAttribute('aria-current', i === index ? 'true' : 'false');
      });

      // Scroll thumb into view
      if (thumbsEl && thumbs[index]) {
        thumbs[index].scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
      }

      currentIndex = index;
    }

    // ---- Thumbnail clicks ----
    thumbs.forEach((thumb, i) => {
      thumb.addEventListener('click', () => goTo(i));
    });

    // ---- Zoom button / image click → lightbox ----
    if (lightboxEl && lightboxContent) {
      function openLightbox(index) {
        const slide = slides[index];
        const img = slide?.querySelector('img');
        if (!img) return;

        const zoomedImg = img.cloneNode(true);
        zoomedImg.removeAttribute('width');
        zoomedImg.removeAttribute('height');
        zoomedImg.removeAttribute('loading');
        zoomedImg.style.width = 'auto';
        zoomedImg.style.height = 'auto';
        zoomedImg.style.maxWidth = '90vw';
        zoomedImg.style.maxHeight = '90vh';

        lightboxContent.innerHTML = '';
        lightboxContent.appendChild(zoomedImg);
        lightboxEl.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
      }

      function closeLightbox() {
        lightboxEl.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
      }

      // Zoom btn
      mainEl.addEventListener('click', (e) => {
        if (e.target.closest('[data-gallery-zoom]') || e.target.closest('.product-gallery__img')) {
          openLightbox(currentIndex);
        }
      });

      // Close
      lightboxEl.querySelectorAll('[data-lightbox-close]').forEach((el) => {
        el.addEventListener('click', closeLightbox);
      });

      // Prev / next in lightbox
      const prevBtn = lightboxEl.querySelector('[data-lightbox-prev]');
      const nextBtn = lightboxEl.querySelector('[data-lightbox-next]');
      if (prevBtn) prevBtn.addEventListener('click', () => { goTo(currentIndex - 1); openLightbox(currentIndex); });
      if (nextBtn) nextBtn.addEventListener('click', () => { goTo(currentIndex + 1); openLightbox(currentIndex); });

      // Keyboard
      document.addEventListener('keydown', (e) => {
        if (lightboxEl.getAttribute('aria-hidden') !== 'false') return;
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowLeft') { goTo(currentIndex - 1); openLightbox(currentIndex); }
        if (e.key === 'ArrowRight') { goTo(currentIndex + 1); openLightbox(currentIndex); }
      });
    }

    // ---- Touch swipe ----
    mainEl.addEventListener('touchstart', (e) => {
      touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });

    mainEl.addEventListener('touchend', (e) => {
      touchEndX = e.changedTouches[0].screenX;
      const delta = touchStartX - touchEndX;
      if (Math.abs(delta) > 50) {
        goTo(delta > 0 ? currentIndex + 1 : currentIndex - 1);
      }
    }, { passive: true });

    // ---- Keyboard arrow navigation ----
    mainEl.setAttribute('tabindex', '0');
    mainEl.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft') goTo(currentIndex - 1);
      if (e.key === 'ArrowRight') goTo(currentIndex + 1);
    });
  }

  /* -----------------------------------------------------------------------
     Init
  ----------------------------------------------------------------------- */

  function init() {
    document.querySelectorAll('[id^="ProductGallery-"]').forEach(initGallery);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
