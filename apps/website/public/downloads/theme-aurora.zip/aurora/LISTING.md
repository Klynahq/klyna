# Aurora — Theme Store Listing

## Theme name
Aurora by Klyna

## Tagline
Minimal, lightning-fast, and built to convert. Aurora is the theme for modern DTC brands.

## Short description (140 chars)
A dark, minimal OS 2.0 theme with a sticky buy bar, AJAX cart, and polished product pages that turn browsers into buyers.

## Full description

**Aurora is built for brands that believe every pixel and every millisecond matters.**

Designed by Klyna — a studio obsessed with minimal, high-performance digital experiences — Aurora brings together a premium dark aesthetic, a conversion-focused product page, and sub-second load times.

### Design philosophy
Aurora draws inspiration from the editorial restraint of Apple.com and the brand clarity of leading DTC stores. The default palette is a near-black zinc with a soft aurora-violet accent, but every colour is fully configurable. The result: stores that look expensive without trying.

### Conversion features
- **Sticky buy bar** — floats in as customers scroll past the main CTA, keeping "Add to Cart" always accessible without being intrusive.
- **Trust badges row** — free returns, secure payment, and fast shipping appear directly below the buy button to neutralise hesitation.
- **AJAX cart drawer** — a slide-in cart keeps shoppers on the page instead of redirecting them away mid-browse.
- **Quick-add** — for single-variant products, customers can add to cart directly from the collection grid.
- **Hover second image** — product cards reveal a lifestyle shot on hover, powered by CSS with zero JS overhead.
- **Predictive variant URL updates** — selecting a variant updates the URL without a reload, making sharing and SEO-friendly deep-links trivial.

### Performance
- Mobile-first CSS, no render-blocking JavaScript.
- All images use Shopify's `image_url` with proper `srcset`, `sizes`, and `loading="lazy"`.
- Deferred script loading for non-critical JS.
- Zero layout shift: aspect-ratio locked image containers throughout.
- Structured data (Product + Organisation JSON-LD) included out of the box.

### Customisation
Aurora's theme editor exposes 50+ settings across colour, typography, layout, product cards, and cart behaviour — all without touching code. Three colour presets (Dark, Light, Midnight) let merchants switch the entire palette in one click.

---

## Keywords
minimal shopify theme, dark shopify theme, DTC theme, conversion shopify theme, fast shopify theme, premium shopify theme, Online Store 2.0, ajax cart shopify, sticky buy bar, product page shopify

## Categories
- Clothing & Fashion
- Beauty & Cosmetics
- Electronics & Tech Accessories
- Home & Lifestyle
- Food & Beverage

## Target merchant profile
- Direct-to-consumer (DTC) brands in fashion, beauty, wellness, or home
- Founders who care deeply about brand presentation
- Stores currently losing conversions to a cluttered or slow theme
- Brands migrating from custom Liquid themes who want a solid OS 2.0 foundation
- 6–8 figure revenue stores with product-forward catalogues (2–200 SKUs)

## Price point recommendation
$280 — $340 USD (one-time licence, Shopify Theme Store)

## Supported languages
English (default). Full `t:` key coverage — additional locale files can be added by the merchant or a developer.

## Supported currencies
All Shopify-supported currencies (multi-currency via Markets is compatible).

## Compatible apps
- Shopify Product Reviews (`#shopify-product-reviews` mount point included)
- Klaviyo / Mailchimp (newsletter form uses Shopify's `contact` form with tags)
- Okendo / Judge.me (reviews section renders their install div)
- ReCharge / Skio (subscription selling plans render correctly in the variant picker)
- Shogun / PageFly (sections-everywhere architecture is compatible)
