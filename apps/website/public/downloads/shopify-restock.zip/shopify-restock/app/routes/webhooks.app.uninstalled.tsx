import { type ActionFunctionArgs } from '@remix-run/node';
import { authenticate } from '../shopify.server';
import prisma from '../db.server';

export const action = async ({ request }: ActionFunctionArgs) => {
  const { shop, session, topic } = await authenticate.webhook(request);
  console.log(`Received ${topic} webhook for ${shop}`);

  // Webhooks can fire after the session is already gone, so guard the cleanup.
  if (session) {
    await prisma.session.deleteMany({ where: { shop } });
  }
  return new Response();
};
