const s=e=>typeof e=="object"&&e!==null&&"type"in e;export{s as i};
