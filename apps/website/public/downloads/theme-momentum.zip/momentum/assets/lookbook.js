/**
 * Momentum by Klyna — lookbook.js
 * Hotspot click → product quick-view panel
 */

'use strict';

class LookbookHotspots {
  constructor() {
    this.modal = document.getElementById('quick-view-modal');
    this.content = document.getElementById('quick-view-content');
    if (!this.modal) return;

    this.init();
  }

  init() {
    document.addEventListener('click', (e) => {
      const hotspot = e.target.closest('[data-hotspot]');
      if (hotspot) {
        e.preventDefault();
        const handle = hotspot.dataset.product;
        if (handle) this.openQuickView(handle);
      }

      const quickViewBtn = e.target.closest('[data-quick-view]');
      if (quickViewBtn) {
        e.preventDefault();
        const handle = quickViewBtn.dataset.quickView;
        if (handle) this.openQuickView(handle);
      }
    });

    // Close handlers
    document.querySelectorAll('[data-quick-view-close]').forEach(el => {
      el.addEventListener('click', () => this.close());
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.modal.classList.contains('is-open')) this.close();
    });
  }

  async openQuickView(handle) {
    this.modal.classList.add('is-open');
    this.modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';

    if (this.content) {
      this.content.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:center;padding:4rem;color:var(--color-muted)">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:32px;height:32px;animation:spin 1s linear infinite">
            <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
          </svg>
        </div>
      `;
    }

    try {
      const url = `/products/${handle}?section_id=main-product&view=quick-view`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const text = await res.text();
      const parser = new DOMParser();
      const doc = parser.parseFromString(text, 'text/html');

      // Try to find the section content
      const sectionContent = doc.querySelector('.shopify-section') || doc.querySelector('.pdp');

      if (sectionContent && this.content) {
        this.content.innerHTML = sectionContent.innerHTML;
        // Re-init scripts within quick view
        this.content.querySelectorAll('.variant-picker').forEach(el => {
          if (window.VariantPicker) new window.VariantPicker(el);
        });
      } else {
        // Fallback: render a clean quick view from the product JSON
        await this.renderFallbackQuickView(handle);
      }
    } catch (err) {
      if (this.content) {
        this.content.innerHTML = `<div style="padding:2rem;text-align:center;color:var(--color-muted)">Unable to load product.</div>`;
      }
    }
  }

  async renderFallbackQuickView(handle) {
    try {
      const res = await fetch(`/products/${handle}.js`);
      if (!res.ok) throw new Error();
      const product = await res.json();

      const imgSrc = product.featured_image || '';
      const price = new Intl.NumberFormat('en-US', { style: 'currency', currency: window.Shopify?.currency?.active || 'USD' }).format(product.price / 100);

      this.content.innerHTML = `
        <div style="display:grid;grid-template-columns:1fr 1fr;min-height:400px">
          <div style="overflow:hidden;border-radius:var(--radius) 0 0 var(--radius)">
            <img src="${imgSrc}" alt="${product.title}" style="width:100%;height:100%;object-fit:cover">
          </div>
          <div style="padding:2.5rem;display:flex;flex-direction:column;gap:1rem">
            ${product.vendor ? `<p style="font-size:.7rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--color-muted)">${product.vendor}</p>` : ''}
            <h2 style="font-size:1.5rem;font-weight:800;letter-spacing:-.03em">${product.title}</h2>
            <p style="font-size:1.25rem;font-weight:700">${price}</p>
            <p style="color:var(--color-muted);font-size:.875rem;line-height:1.6">${product.description ? product.description.replace(/<[^>]+>/g, '').slice(0, 200) + '...' : ''}</p>
            <a href="/products/${handle}" class="btn btn--primary" style="margin-top:auto">View Full Details</a>
          </div>
        </div>
      `;
    } catch {
      this.content.innerHTML = `<div style="padding:2rem;text-align:center">Product not found.</div>`;
    }
  }

  close() {
    this.modal.classList.remove('is-open');
    this.modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }
}

// Add spin keyframe
const style = document.createElement('style');
style.textContent = '@keyframes spin { to { transform: rotate(360deg); } }';
document.head.appendChild(style);

document.addEventListener('DOMContentLoaded', () => {
  window.Momentum = window.Momentum || {};
  window.Momentum.lookbook = new LookbookHotspots();
});
