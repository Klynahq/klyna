/**
 * Momentum by Klyna — global.js
 * Vanilla JS: cart AJAX, variant select, mega-menu, mobile drawer,
 * sticky header, predictive search, lazy load, complementary products
 */

'use strict';

/* --------------------------------------------------------------------------
   Utilities
   -------------------------------------------------------------------------- */

const MomentumUtils = {
  /**
   * Debounce function execution
   */
  debounce(fn, delay = 300) {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), delay);
    };
  },

  /**
   * Trap focus within an element
   */
  trapFocus(el) {
    const focusable = el.querySelectorAll(
      'a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    const first = focusable[0];
    const last = focusable[focusable.length - 1];

    const onKeyDown = (e) => {
      if (e.key !== 'Tab') return;
      if (e.shiftKey) {
        if (document.activeElement === first) {
          e.preventDefault();
          last.focus();
        }
      } else {
        if (document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };

    el.addEventListener('keydown', onKeyDown);
    if (first) first.focus();
    return () => el.removeEventListener('keydown', onKeyDown);
  },

  /**
   * Format money amount (cents) using Shopify money format
   */
  formatMoney(cents) {
    const formatter = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: window.Shopify?.currency?.active || 'USD',
      minimumFractionDigits: 2,
    });
    return formatter.format(cents / 100);
  },

  /**
   * Parse HTML string into DOM
   */
  parseHTML(html) {
    const parser = new DOMParser();
    return parser.parseFromString(html, 'text/html');
  },

  /**
   * Fetch JSON from URL
   */
  async fetchJSON(url, opts = {}) {
    const res = await fetch(url, { headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, ...opts });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  }
};

/* --------------------------------------------------------------------------
   Sticky Header
   -------------------------------------------------------------------------- */

class StickyHeader {
  constructor() {
    this.header = document.querySelector('.header');
    if (!this.header) return;

    this.lastScrollY = 0;
    this.ticking = false;
    this.type = this.header.dataset.stickyType || 'on-scroll-up';

    window.addEventListener('scroll', () => this.onScroll(), { passive: true });
  }

  onScroll() {
    if (!this.ticking) {
      requestAnimationFrame(() => {
        this.update();
        this.ticking = false;
      });
      this.ticking = true;
    }
  }

  update() {
    const scrollY = window.scrollY;
    const scrollingDown = scrollY > this.lastScrollY;
    const scrolledPast = scrollY > this.header.offsetHeight;

    if (this.type === 'on-scroll-up') {
      if (scrollingDown && scrolledPast) {
        this.header.classList.add('header--hidden');
      } else {
        this.header.classList.remove('header--hidden');
      }
    }

    this.lastScrollY = scrollY;
  }
}

/* --------------------------------------------------------------------------
   Mega Menu
   -------------------------------------------------------------------------- */

class MegaMenu {
  constructor() {
    this.items = document.querySelectorAll('.header__nav-item--has-mega, .header__nav-item--has-dropdown');
    this.init();
  }

  init() {
    this.items.forEach(item => {
      const trigger = item.querySelector('[data-mega-trigger]');
      const menu = item.querySelector('[data-mega-menu], [data-dropdown]');
      if (!trigger || !menu) return;

      // Keyboard navigation
      trigger.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          const isOpen = trigger.getAttribute('aria-expanded') === 'true';
          this.closeAll();
          if (!isOpen) this.open(trigger, menu);
        }
        if (e.key === 'Escape') {
          this.closeAll();
          trigger.focus();
        }
      });

      // Close on Escape from within
      menu.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          this.closeAll();
          trigger.focus();
        }
      });
    });

    // Close on click outside
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.header__nav-item')) this.closeAll();
    });
  }

  open(trigger, menu) {
    trigger.setAttribute('aria-expanded', 'true');
    menu.setAttribute('aria-hidden', 'false');
  }

  closeAll() {
    document.querySelectorAll('[data-mega-trigger]').forEach(t => t.setAttribute('aria-expanded', 'false'));
    document.querySelectorAll('[data-mega-menu], [data-dropdown]').forEach(m => m.setAttribute('aria-hidden', 'true'));
  }
}

/* --------------------------------------------------------------------------
   Mobile Drawer
   -------------------------------------------------------------------------- */

class MobileDrawer {
  constructor() {
    this.drawer = document.getElementById('mobile-drawer');
    this.toggle = document.querySelector('[data-mobile-toggle]');
    if (!this.drawer || !this.toggle) return;

    this.isOpen = false;
    this.removeTrap = null;

    this.toggle.addEventListener('click', () => this.open());
    document.querySelectorAll('[data-mobile-close]').forEach(el => {
      el.addEventListener('click', () => this.close());
    });

    // Accordion parents
    document.querySelectorAll('[data-mobile-parent]').forEach(btn => {
      btn.addEventListener('click', () => {
        const subList = btn.nextElementSibling;
        const isExpanded = btn.getAttribute('aria-expanded') === 'true';
        btn.setAttribute('aria-expanded', isExpanded ? 'false' : 'true');
        subList.hidden = isExpanded;
      });
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.isOpen) this.close();
    });
  }

  open() {
    this.isOpen = true;
    this.drawer.classList.add('is-open');
    this.drawer.setAttribute('aria-hidden', 'false');
    this.toggle.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
    this.removeTrap = MomentumUtils.trapFocus(this.drawer);
  }

  close() {
    this.isOpen = false;
    this.drawer.classList.remove('is-open');
    this.drawer.setAttribute('aria-hidden', 'true');
    this.toggle.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    if (this.removeTrap) { this.removeTrap(); this.removeTrap = null; }
    this.toggle.focus();
  }
}

/* --------------------------------------------------------------------------
   Search Drawer
   -------------------------------------------------------------------------- */

class SearchDrawer {
  constructor() {
    this.drawer = document.getElementById('search-drawer');
    this.input = document.getElementById('search-drawer-input');
    this.results = document.getElementById('predictive-search-results');
    if (!this.drawer) return;

    document.querySelectorAll('[data-search-open]').forEach(el => {
      el.addEventListener('click', () => this.open());
    });

    document.querySelectorAll('[data-search-close]').forEach(el => {
      el.addEventListener('click', () => this.close());
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.drawer.classList.contains('is-open')) this.close();
    });

    if (this.input) {
      this.input.addEventListener('input', MomentumUtils.debounce(() => this.predictiveSearch(), 300));
    }
  }

  open() {
    this.drawer.classList.add('is-open');
    this.drawer.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    setTimeout(() => this.input && this.input.focus(), 100);
  }

  close() {
    this.drawer.classList.remove('is-open');
    this.drawer.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  async predictiveSearch() {
    const query = this.input.value.trim();
    if (!query || query.length < 2) {
      this.results.innerHTML = '';
      return;
    }

    try {
      const url = `${window.Shopify?.routes?.root_url || '/'}search/suggest?q=${encodeURIComponent(query)}&resources[type]=product&resources[limit]=6&section_id=predictive-search`;
      const res = await fetch(url);
      if (!res.ok) return;
      const text = await res.text();
      const doc = MomentumUtils.parseHTML(text);
      const sectionContent = doc.querySelector('.shopify-section');
      if (sectionContent) {
        this.results.innerHTML = sectionContent.innerHTML;
      }
    } catch (err) {
      // silently fail
    }
  }
}

/* --------------------------------------------------------------------------
   Cart — AJAX Add & Update
   -------------------------------------------------------------------------- */

class CartManager {
  constructor() {
    this.cartCount = document.getElementById('cart-count');
    this.init();
  }

  init() {
    // Quick-add buttons (product cards)
    document.addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-quick-add]');
      if (!btn) return;
      e.preventDefault();
      await this.addItem(btn.dataset.quickAdd, 1, btn);
    });

    // Product form add-to-cart
    document.addEventListener('submit', async (e) => {
      const form = e.target.closest('[data-type="add-to-cart-form"]');
      if (!form) return;
      e.preventDefault();

      const formData = new FormData(form);
      const btn = form.querySelector('[data-add-to-cart]');
      if (btn) {
        btn.disabled = true;
        const textEl = btn.querySelector('[data-add-to-cart-text]');
        if (textEl) textEl.textContent = window.theme_strings?.adding || 'Adding...';
      }

      try {
        const data = await MomentumUtils.fetchJSON('/cart/add.js', {
          method: 'POST',
          body: formData,
          headers: {}
        });
        await this.refreshCart();
        this.openCartDrawer();
        if (btn) {
          const textEl = btn.querySelector('[data-add-to-cart-text]');
          if (textEl) textEl.textContent = window.theme_strings?.added || 'Added!';
          setTimeout(() => {
            btn.disabled = false;
            if (textEl) textEl.textContent = window.theme_strings?.add_to_cart || 'Add to Cart';
          }, 2000);
        }
      } catch (err) {
        if (btn) {
          btn.disabled = false;
          const textEl = btn.querySelector('[data-add-to-cart-text]');
          if (textEl) textEl.textContent = window.theme_strings?.add_to_cart || 'Add to Cart';
        }
        console.error('Add to cart error:', err);
      }
    });

    // Sticky bar add-to-cart
    document.addEventListener('click', (e) => {
      if (e.target.closest('[data-sticky-add]')) {
        const mainForm = document.querySelector('[data-type="add-to-cart-form"]');
        if (mainForm) mainForm.querySelector('[data-add-to-cart]')?.click();
      }
    });
  }

  async addItem(variantId, quantity = 1, btn = null) {
    if (btn) { btn.disabled = true; }

    try {
      await MomentumUtils.fetchJSON('/cart/add.js', {
        method: 'POST',
        body: JSON.stringify({ id: variantId, quantity })
      });
      await this.refreshCart();
      this.openCartDrawer();
    } finally {
      if (btn) { btn.disabled = false; }
    }
  }

  async refreshCart() {
    try {
      const cart = await MomentumUtils.fetchJSON('/cart.js');
      this.updateCartCount(cart.item_count);
      await this.renderCartDrawer(cart);
    } catch (err) {
      console.error('Cart refresh error:', err);
    }
  }

  updateCartCount(count) {
    if (!this.cartCount) return;
    this.cartCount.textContent = count;
    this.cartCount.classList.toggle('hidden', count === 0);
    // Update aria-label on button
    const btn = document.querySelector('[data-cart-open]');
    if (btn) btn.setAttribute('aria-label', `Cart (${count})`);
  }

  async renderCartDrawer(cart) {
    const itemsEl = document.getElementById('cart-drawer-items');
    const footerEl = document.getElementById('cart-drawer-footer');
    if (!itemsEl || !footerEl) return;

    if (cart.item_count === 0) {
      itemsEl.innerHTML = `<p style="text-align:center;padding:2rem;color:var(--color-muted)">${window.theme_strings?.cart_empty || 'Your cart is empty'}</p>`;
      footerEl.innerHTML = '';
      return;
    }

    const itemsHtml = cart.items.map(item => `
      <div class="cart-item" style="grid-template-columns:80px 1fr;padding:.75rem 0;border-bottom:1px solid var(--color-border)">
        <a href="${item.url}">
          <img src="${item.image}" alt="${item.title}" style="width:80px;height:100px;object-fit:cover;border-radius:var(--radius-sm)">
        </a>
        <div style="padding-left:.75rem;display:flex;flex-direction:column;gap:.25rem">
          <a href="${item.url}" style="font-weight:700;font-size:.875rem">${item.product_title}</a>
          ${item.variant_title !== 'Default Title' ? `<span style="font-size:.8rem;color:var(--color-muted)">${item.variant_title}</span>` : ''}
          <span style="font-weight:700;font-size:.875rem">${MomentumUtils.formatMoney(item.final_line_price)}</span>
          <div style="display:flex;align-items:center;gap:.5rem;margin-top:.25rem">
            <button class="cart-item__qty-btn" onclick="window.Momentum.cart.updateItem('${item.key}', ${item.quantity - 1})" aria-label="Decrease">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px"><path d="M5 12h14"/></svg>
            </button>
            <span style="font-size:.875rem;font-weight:700;min-width:20px;text-align:center">${item.quantity}</span>
            <button class="cart-item__qty-btn" onclick="window.Momentum.cart.updateItem('${item.key}', ${item.quantity + 1})" aria-label="Increase">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px"><path d="M12 5v14"/><path d="M5 12h14"/></svg>
            </button>
            <button onclick="window.Momentum.cart.updateItem('${item.key}', 0)" style="margin-left:auto;color:var(--color-muted);padding:.25rem" aria-label="Remove">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:16px;height:16px"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
            </button>
          </div>
        </div>
      </div>
    `).join('');

    footerEl.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;font-weight:800">
        <span>${window.theme_strings?.subtotal || 'Subtotal'}</span>
        <span>${MomentumUtils.formatMoney(cart.total_price)}</span>
      </div>
      <a href="/checkout" class="btn btn--primary btn--full" style="margin-bottom:.75rem">${window.theme_strings?.checkout || 'Checkout'}</a>
      <a href="/cart" class="btn btn--outline btn--full">${window.theme_strings?.view_cart || 'View Cart'}</a>
    `;

    itemsEl.innerHTML = itemsHtml;
  }

  async updateItem(key, quantity) {
    try {
      await MomentumUtils.fetchJSON('/cart/change.js', {
        method: 'POST',
        body: JSON.stringify({ id: key, quantity })
      });
      await this.refreshCart();
    } catch (err) {
      console.error('Cart update error:', err);
    }
  }

  openCartDrawer() {
    window.Momentum?.cartDrawer?.open();
  }
}

/* --------------------------------------------------------------------------
   Variant Picker + URL Update
   -------------------------------------------------------------------------- */

class VariantPicker {
  constructor(container) {
    this.container = container;
    this.productUrl = container.dataset.url;
    this.sectionId = container.dataset.section;
    this.variantsData = JSON.parse(container.querySelector('[data-product-variants]')?.textContent || '[]');

    this.init();
  }

  init() {
    this.container.querySelectorAll('[data-option-input]').forEach(input => {
      input.addEventListener('change', () => this.onOptionChange());
    });
  }

  getSelectedOptions() {
    const options = {};
    this.container.querySelectorAll('[data-option-select]').forEach(select => {
      options[select.dataset.optionSelect] = select.value;
    });
    this.container.querySelectorAll('[data-option-input]:checked').forEach(input => {
      options[input.dataset.optionInput] = input.value;
    });
    return options;
  }

  findVariant(selectedOptions) {
    return this.variantsData.find(v =>
      v.options.every((opt, i) => {
        const optionKey = Object.keys(selectedOptions)[i];
        return opt === selectedOptions[optionKey];
      })
    );
  }

  onOptionChange() {
    const selectedOptions = this.getSelectedOptions();
    const variant = this.findVariant(selectedOptions);
    if (!variant) return;

    // Update URL
    const url = new URL(window.location.href);
    url.searchParams.set('variant', variant.id);
    window.history.replaceState({}, '', url.toString());

    // Update hidden variant input in form
    const variantInput = document.querySelector(`[data-variant-select][data-productid]`);
    if (variantInput) variantInput.value = variant.id;

    // Update price
    const priceEl = document.getElementById(`price-${this.sectionId}`);
    if (priceEl) {
      const current = priceEl.querySelector('.price__current');
      const compare = priceEl.querySelector('.price__compare');
      if (current) current.textContent = MomentumUtils.formatMoney(variant.price);
      if (compare) {
        if (variant.compare_at_price && variant.compare_at_price > variant.price) {
          compare.style.display = '';
          compare.querySelector('s').textContent = MomentumUtils.formatMoney(variant.compare_at_price);
        } else {
          compare.style.display = 'none';
        }
      }
    }

    // Update add-to-cart button
    const addBtn = document.querySelector('[data-add-to-cart]');
    if (addBtn) {
      addBtn.disabled = !variant.available;
      const textEl = addBtn.querySelector('[data-add-to-cart-text]');
      if (textEl) {
        textEl.textContent = variant.available
          ? (window.theme_strings?.add_to_cart || 'Add to Cart')
          : (window.theme_strings?.sold_out || 'Sold Out');
      }
    }

    // Update selected option labels
    this.container.querySelectorAll('[data-option-selected]').forEach(label => {
      const optionName = label.dataset.optionSelected;
      if (selectedOptions[optionName] !== undefined) {
        label.textContent = selectedOptions[optionName];
      }
    });

    // Update active button states
    this.container.querySelectorAll('.variant-picker__btn').forEach(btn => {
      const input = btn.querySelector('input');
      if (input) btn.classList.toggle('variant-picker__btn--active', input.checked);
    });

    this.container.querySelectorAll('.variant-picker__swatch').forEach(swatch => {
      const input = swatch.querySelector('input');
      if (input) swatch.classList.toggle('variant-picker__swatch--active', input.checked);
    });

    // Dispatch event for other modules
    document.dispatchEvent(new CustomEvent('variant:change', { detail: { variant } }));
  }
}

/* --------------------------------------------------------------------------
   Sticky PDP Buy Bar
   -------------------------------------------------------------------------- */

class StickyBuyBar {
  constructor() {
    this.bar = document.querySelector('.pdp__sticky-bar');
    this.buyBtn = document.querySelector('.pdp__add-btn');
    if (!this.bar || !this.buyBtn) return;

    this.observer = new IntersectionObserver(
      ([entry]) => this.bar.classList.toggle('is-visible', !entry.isIntersecting),
      { threshold: 0, rootMargin: '0px' }
    );
    this.observer.observe(this.buyBtn);
  }
}

/* --------------------------------------------------------------------------
   Quantity Input (PDP)
   -------------------------------------------------------------------------- */

class QuantityInput {
  constructor() {
    document.addEventListener('click', (e) => {
      const minusBtn = e.target.closest('[data-qty-minus]');
      const plusBtn = e.target.closest('[data-qty-plus]');
      if (!minusBtn && !plusBtn) return;

      const wrap = (minusBtn || plusBtn).closest('.pdp__quantity-input');
      if (!wrap) return;
      const input = wrap.querySelector('[data-quantity-input]');
      if (!input) return;

      const current = parseInt(input.value, 10) || 1;
      if (minusBtn) input.value = Math.max(1, current - 1);
      if (plusBtn) input.value = current + 1;
    });
  }
}

/* --------------------------------------------------------------------------
   Complementary Products (Product Recommendations API)
   -------------------------------------------------------------------------- */

class ComplementaryProducts {
  constructor() {
    const section = document.querySelector('[data-section-type="complementary-products"]');
    if (!section) return;

    const productId = section.dataset.productId;
    const limit = section.dataset.limit || 4;
    const sectionId = section.dataset.sectionId;
    if (!productId) return;

    const url = `${window.Shopify?.routes?.root_url || '/'}recommendations/products?product_id=${productId}&limit=${limit}&section_id=${sectionId}`;
    this.load(url, section);
  }

  async load(url, section) {
    try {
      const res = await fetch(url);
      if (!res.ok) return;
      const text = await res.text();
      const doc = MomentumUtils.parseHTML(text);
      const inner = doc.querySelector('.shopify-section');
      if (inner) {
        const grid = section.querySelector('#complementary-products-grid');
        if (grid) grid.innerHTML = inner.querySelector('#complementary-products-grid')?.innerHTML || '';
      }
    } catch (err) {
      // no recommendations
    }
  }
}

/* --------------------------------------------------------------------------
   Parallax (CSS-driven scroll transform)
   -------------------------------------------------------------------------- */

class ParallaxImages {
  constructor() {
    this.images = document.querySelectorAll('.js-parallax');
    if (!this.images.length) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    window.addEventListener('scroll', () => this.update(), { passive: true });
    this.update();
  }

  update() {
    this.images.forEach(img => {
      const rect = img.closest('.image-banner')?.getBoundingClientRect();
      if (!rect) return;
      const scrolled = (rect.top / window.innerHeight) * 30;
      img.style.transform = `scale(1.05) translateY(${scrolled}px)`;
    });
  }
}

/* --------------------------------------------------------------------------
   In-View Animations
   -------------------------------------------------------------------------- */

class InViewObserver {
  constructor() {
    if (!('IntersectionObserver' in window)) return;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.image-banner, .split-hero, .rich-text, .featured-collection, .testimonial').forEach(el => {
      observer.observe(el);
    });
  }
}

/* --------------------------------------------------------------------------
   Init
   -------------------------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', () => {
  window.Momentum = window.Momentum || {};

  // Core
  new StickyHeader();
  new MegaMenu();
  new MobileDrawer();
  new SearchDrawer();
  new QuantityInput();
  new StickyBuyBar();
  new ComplementaryProducts();
  new ParallaxImages();
  new InViewObserver();

  // Cart
  window.Momentum.cart = new CartManager();

  // Variant pickers
  document.querySelectorAll('.variant-picker').forEach(el => new VariantPicker(el));

  // Cart drawer button
  document.querySelectorAll('[data-cart-open]').forEach(btn => {
    btn.addEventListener('click', () => window.Momentum?.cartDrawer?.open());
  });
});
