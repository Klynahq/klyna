/**
 * Momentum by Klyna — product-media.js
 * Gallery navigation, lightbox, swipe support
 */

'use strict';

class ProductGallery {
  constructor(container) {
    this.container = container;
    this.items = [...container.querySelectorAll('[data-gallery-item]')];
    this.thumbs = [...container.querySelectorAll('[data-gallery-thumb]')];
    this.currentIndex = 0;
    this.startX = 0;
    this.startY = 0;

    if (!this.items.length) return;

    this.init();
  }

  init() {
    // Previous / Next arrows
    this.container.querySelector('[data-gallery-prev]')?.addEventListener('click', () => this.prev());
    this.container.querySelector('[data-gallery-next]')?.addEventListener('click', () => this.next());

    // Thumbnail clicks
    this.thumbs.forEach((thumb, i) => {
      thumb.addEventListener('click', () => this.goTo(i));
    });

    // Lightbox triggers
    this.container.querySelectorAll('[data-lightbox-open]').forEach(btn => {
      btn.addEventListener('click', () => {
        const mediaId = btn.dataset.lightboxOpen;
        this.openLightbox(mediaId);
      });
    });

    // Touch / swipe on main
    const main = this.container.querySelector('[data-gallery-main]');
    if (main) {
      main.addEventListener('touchstart', (e) => {
        this.startX = e.touches[0].clientX;
        this.startY = e.touches[0].clientY;
      }, { passive: true });

      main.addEventListener('touchend', (e) => {
        const dx = e.changedTouches[0].clientX - this.startX;
        const dy = e.changedTouches[0].clientY - this.startY;
        if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 40) {
          dx > 0 ? this.prev() : this.next();
        }
      }, { passive: true });
    }

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
      if (this.lightboxOpen) {
        if (e.key === 'ArrowLeft') this.lightboxPrev();
        if (e.key === 'ArrowRight') this.lightboxNext();
        if (e.key === 'Escape') this.closeLightbox();
      }
    });

    // Listen for variant changes to update featured media
    document.addEventListener('variant:change', (e) => {
      const variant = e.detail.variant;
      if (variant.featured_media) {
        const mediaId = String(variant.featured_media.id);
        const idx = this.items.findIndex(item => item.dataset.mediaId === mediaId);
        if (idx !== -1) this.goTo(idx);
      }
    });

    // Find initial active index
    const activeItem = this.container.querySelector('.product-gallery__item--active');
    if (activeItem) {
      this.currentIndex = this.items.indexOf(activeItem);
    }
  }

  goTo(index) {
    if (index < 0 || index >= this.items.length) return;

    this.items[this.currentIndex]?.classList.remove('product-gallery__item--active');
    this.thumbs[this.currentIndex]?.classList.remove('product-gallery__thumb--active');

    this.currentIndex = index;

    this.items[this.currentIndex]?.classList.add('product-gallery__item--active');
    this.thumbs[this.currentIndex]?.classList.add('product-gallery__thumb--active');

    // Scroll thumb into view
    this.thumbs[this.currentIndex]?.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
  }

  prev() {
    this.goTo((this.currentIndex - 1 + this.items.length) % this.items.length);
  }

  next() {
    this.goTo((this.currentIndex + 1) % this.items.length);
  }

  /* ---------- Lightbox ---------- */

  openLightbox(mediaId) {
    const lightbox = this.container.querySelector('[data-lightbox]');
    if (!lightbox) return;

    this.lightbox = lightbox;
    this.lightboxItems = [...lightbox.querySelectorAll('[data-lightbox-item]')];
    this.lightboxIndex = this.lightboxItems.findIndex(item => item.dataset.lightboxId === mediaId);
    if (this.lightboxIndex === -1) this.lightboxIndex = 0;

    this.lightboxOpen = true;
    lightbox.classList.add('is-open');
    lightbox.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';

    this.renderLightbox();

    // Close handlers
    lightbox.querySelectorAll('[data-lightbox-close]').forEach(el => {
      el.addEventListener('click', () => this.closeLightbox());
    });
    lightbox.querySelector('[data-lightbox-prev]')?.addEventListener('click', () => this.lightboxPrev());
    lightbox.querySelector('[data-lightbox-next]')?.addEventListener('click', () => this.lightboxNext());
  }

  renderLightbox() {
    this.lightboxItems.forEach((item, i) => {
      item.classList.toggle('is-active', i === this.lightboxIndex);
    });
  }

  lightboxPrev() {
    this.lightboxIndex = (this.lightboxIndex - 1 + this.lightboxItems.length) % this.lightboxItems.length;
    this.renderLightbox();
  }

  lightboxNext() {
    this.lightboxIndex = (this.lightboxIndex + 1) % this.lightboxItems.length;
    this.renderLightbox();
  }

  closeLightbox() {
    if (!this.lightbox) return;
    this.lightboxOpen = false;
    this.lightbox.classList.remove('is-open');
    this.lightbox.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-gallery]').forEach(container => new ProductGallery(container));
});
