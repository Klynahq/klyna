/**
 * Momentum by Klyna — filters.js
 * AJAX filtering + sorting for collection pages
 */

'use strict';

class CollectionFilters {
  constructor() {
    this.form = null;
    this.productGrid = document.getElementById('product-grid');
    if (!this.productGrid) return;

    this.currentUrl = new URL(window.location.href);
    this.init();
  }

  init() {
    // Filter inputs
    document.querySelectorAll('[data-filter-input]').forEach(input => {
      input.addEventListener('change', () => this.applyFilters());
    });

    // Price range filters
    document.querySelectorAll('[data-price-filter]').forEach(input => {
      input.addEventListener('change', () => this.applyFilters());
    });

    // Sort select
    document.querySelector('[data-sort-by]')?.addEventListener('change', (e) => {
      this.currentUrl.searchParams.set('sort_by', e.target.value);
      this.fetchProducts(this.currentUrl.toString());
    });

    // Clear filters
    document.querySelector('[data-filter-clear]')?.addEventListener('click', () => {
      const baseUrl = new URL(window.location.href);
      // Remove filter params, keep sort_by
      const sortBy = baseUrl.searchParams.get('sort_by');
      const newUrl = new URL(baseUrl.pathname, window.location.origin);
      if (sortBy) newUrl.searchParams.set('sort_by', sortBy);
      this.fetchProducts(newUrl.toString());
    });

    // Handle browser back/forward
    window.addEventListener('popstate', () => {
      this.fetchProducts(window.location.href, false);
    });
  }

  applyFilters() {
    const filterUrl = new URL(window.location.href);
    // Remove existing filter params
    [...filterUrl.searchParams.keys()].forEach(key => {
      if (key.startsWith('filter.')) filterUrl.searchParams.delete(key);
    });

    // Add active filter inputs
    document.querySelectorAll('[data-filter-input]:checked').forEach(input => {
      filterUrl.searchParams.append(input.name, input.value);
    });

    // Add price range
    const priceMin = document.querySelector('[data-price-filter][name*="min"]');
    const priceMax = document.querySelector('[data-price-filter][name*="max"]');
    if (priceMin?.value) filterUrl.searchParams.set(priceMin.name, priceMin.value);
    if (priceMax?.value) filterUrl.searchParams.set(priceMax.name, priceMax.value);

    // Reset to page 1
    filterUrl.searchParams.delete('page');

    this.fetchProducts(filterUrl.toString());
  }

  async fetchProducts(url, pushState = true) {
    // Show loading state
    this.productGrid.style.opacity = '0.5';
    this.productGrid.style.pointerEvents = 'none';

    try {
      const res = await fetch(url, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const text = await res.text();
      const parser = new DOMParser();
      const doc = parser.parseFromString(text, 'text/html');

      // Update product grid
      const newGrid = doc.getElementById('product-grid');
      if (newGrid) {
        this.productGrid.innerHTML = newGrid.innerHTML;
      }

      // Update filter sidebar (active states, counts)
      const newFilters = doc.getElementById('collection-filters');
      const currentFilters = document.getElementById('collection-filters');
      if (newFilters && currentFilters) {
        currentFilters.innerHTML = newFilters.innerHTML;
        this.reInitFilters();
      }

      // Update product count
      const newCount = doc.querySelector('.collection-grid__count');
      const currentCount = document.querySelector('.collection-grid__count');
      if (newCount && currentCount) {
        currentCount.textContent = newCount.textContent;
      }

      if (pushState) {
        window.history.pushState({ path: url }, '', url);
      }

      // Scroll to top of grid
      this.productGrid.scrollIntoView({ behavior: 'smooth', block: 'start' });

    } catch (err) {
      console.error('Filter error:', err);
    } finally {
      this.productGrid.style.opacity = '';
      this.productGrid.style.pointerEvents = '';
    }
  }

  reInitFilters() {
    document.querySelectorAll('[data-filter-input]').forEach(input => {
      input.addEventListener('change', () => this.applyFilters());
    });
    document.querySelectorAll('[data-price-filter]').forEach(input => {
      input.addEventListener('change', () => this.applyFilters());
    });
    document.querySelector('[data-filter-clear]')?.addEventListener('click', () => {
      const baseUrl = new URL(window.location.href);
      const sortBy = baseUrl.searchParams.get('sort_by');
      const newUrl = new URL(baseUrl.pathname, window.location.origin);
      if (sortBy) newUrl.searchParams.set('sort_by', sortBy);
      this.fetchProducts(newUrl.toString());
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  new CollectionFilters();
});
