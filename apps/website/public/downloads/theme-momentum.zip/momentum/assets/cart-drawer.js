/**
 * Momentum by Klyna — cart-drawer.js
 * Slide-in cart drawer
 */

'use strict';

class CartDrawer {
  constructor() {
    this.drawer = document.getElementById('cart-drawer');
    if (!this.drawer) return;

    this.isOpen = false;
    this.removeTrap = null;

    this.overlay = this.drawer.querySelector('[data-cart-drawer-overlay]');
    this.closeBtn = this.drawer.querySelector('[data-cart-drawer-close]');

    this.overlay?.addEventListener('click', () => this.close());
    this.closeBtn?.addEventListener('click', () => this.close());

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.isOpen) this.close();
    });

    // Expose globally so CartManager can call it
    window.Momentum = window.Momentum || {};
    window.Momentum.cartDrawer = this;
  }

  open() {
    if (this.isOpen) return;
    this.isOpen = true;
    this.drawer.classList.add('is-open');
    this.drawer.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';

    // Trap focus
    const inner = this.drawer.querySelector('.cart-drawer__inner');
    if (inner) {
      const focusable = inner.querySelectorAll('a, button:not([disabled]), input, [tabindex]:not([tabindex="-1"])');
      const first = focusable[0];
      const last = focusable[focusable.length - 1];

      const onKeyDown = (e) => {
        if (e.key !== 'Tab') return;
        if (e.shiftKey ? document.activeElement === first : document.activeElement === last) {
          e.preventDefault();
          (e.shiftKey ? last : first)?.focus();
        }
      };

      inner.addEventListener('keydown', onKeyDown);
      first?.focus();
      this.removeTrap = () => inner.removeEventListener('keydown', onKeyDown);
    }
  }

  close() {
    if (!this.isOpen) return;
    this.isOpen = false;
    this.drawer.classList.remove('is-open');
    this.drawer.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    if (this.removeTrap) { this.removeTrap(); this.removeTrap = null; }

    // Return focus to cart trigger
    document.querySelector('[data-cart-open]')?.focus();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  new CartDrawer();
});
