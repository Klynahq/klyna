# Momentum by Klyna

> Bold editorial Shopify OS 2.0 theme for big catalogs and brand-led storytelling.

## Design Rationale

**Momentum** is built for fashion and streetwear brands that lead with identity, not just product. Every design decision is intentional:

- **Oversized display type** — fluid clamp-based scale from `3.5rem` up to `9rem`. The headlines feel like posters, not labels.
- **Dark Klyna palette** — `#0b0b0f` background, zinc surface `#1a1a23`, violet accent `#7c5cff`. High contrast. Premium and confident.
- **Full-bleed imagery** — sections like `image-banner`, `collection-banner`, and `split-hero` are designed to run edge-to-edge at all viewport widths.
- **Strong asymmetric grid** — the collection filter sidebar + grid, split-hero, and lookbook all use intentionally offset column ratios that feel editorial rather than template-y.
- **Hover reveals** — product cards keep the surface clean until hover, when a quick-add button slides up from below. Secondary images cross-fade on hover.
- **CSS-only parallax** — the hero banner uses JS-driven `translateY` on scroll for depth without a library.
- **Mega menu** — expands to a full-width panel with columns for nested collections, ideal for big catalogs.
- **Lookbook hotspots** — pin product quickview triggers directly to editorial imagery.

---

## Status

| Area | Status |
|---|---|
| Layout (theme.liquid, password.liquid) | Complete |
| All JSON templates | Complete |
| All sections (header, footer, PDP, collection, marketing) | Complete |
| Customer account sections | Complete |
| Snippets (product-card, price, variant-picker, gallery, icons...) | Complete |
| base.css design system | Complete |
| global.js (AJAX cart, variant, mega-menu, search, parallax) | Complete |
| product-media.js (gallery, lightbox, swipe) | Complete |
| filters.js (AJAX filter+sort) | Complete |
| lookbook.js (hotspot quick-view) | Complete |
| cart-drawer.js | Complete |
| settings_schema.json + settings_data.json | Complete |
| locales/en.default.json | Complete |
| momentum-logo.svg | Complete |

---

## Preview with Shopify CLI

```bash
# Install Shopify CLI if you haven't
npm install -g @shopify/cli @shopify/theme

# From the theme root (where this README lives)
shopify theme dev --store=your-store.myshopify.com
```

> The theme root for the CLI is the `momentum/` directory — the folder containing `layout/`, `templates/`, etc.

## Push to Theme Store staging

```bash
shopify theme push --store=your-store.myshopify.com --unpublished
```

---

## File Tree

```
momentum/
├── layout/
│   ├── theme.liquid
│   └── password.liquid
├── templates/
│   ├── index.json
│   ├── product.json
│   ├── collection.json
│   ├── list-collections.json
│   ├── page.json / page.contact.json
│   ├── blog.json / article.json
│   ├── cart.json
│   ├── search.json
│   ├── 404.json
│   ├── password.json
│   └── customers/
│       ├── account.json
│       ├── login.json
│       ├── register.json
│       ├── order.json
│       ├── addresses.json
│       ├── reset_password.json
│       └── activate_account.json
├── sections/
│   ├── header.liquid         (mega-menu, mobile drawer)
│   ├── footer.liquid
│   ├── announcement-bar.liquid
│   ├── main-product.liquid   (full PDP)
│   ├── complementary-products.liquid
│   ├── collection-banner.liquid
│   ├── main-collection-product-grid.liquid
│   ├── image-banner.liquid
│   ├── featured-collection.liquid
│   ├── lookbook.liquid
│   ├── split-hero.liquid
│   ├── rich-text.liquid
│   ├── image-with-text.liquid
│   ├── multicolumn.liquid
│   ├── newsletter.liquid
│   ├── testimonials.liquid
│   ├── collapsible-content.liquid
│   ├── main-cart-items.liquid
│   ├── main-cart-footer.liquid
│   ├── main-page.liquid
│   ├── main-blog.liquid
│   ├── main-article.liquid
│   ├── main-search.liquid
│   ├── main-404.liquid
│   ├── main-list-collections.liquid
│   ├── main-account.liquid
│   ├── main-login.liquid
│   ├── main-register.liquid
│   ├── main-order.liquid
│   ├── main-addresses.liquid
│   ├── main-reset-password.liquid
│   ├── main-activate-account.liquid
│   ├── main-password-header.liquid
│   └── main-password-footer.liquid
├── snippets/
│   ├── product-card.liquid
│   ├── price.liquid
│   ├── product-variant-picker.liquid
│   ├── product-media-gallery.liquid
│   ├── pagination.liquid
│   ├── icon.liquid
│   ├── social-icons.liquid
│   ├── meta-tags.liquid
│   ├── structured-data.liquid
│   └── responsive-image.liquid
├── assets/
│   ├── base.css
│   ├── global.js
│   ├── product-media.js
│   ├── filters.js
│   ├── lookbook.js
│   ├── cart-drawer.js
│   └── momentum-logo.svg
├── config/
│   ├── settings_schema.json
│   └── settings_data.json
└── locales/
    ├── en.default.json
    └── en.default.schema.json
```
