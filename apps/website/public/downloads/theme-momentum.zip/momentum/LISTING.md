# Momentum by Klyna — Theme Store Listing

## Theme Name
**Momentum**

## Tagline
Bold editorial commerce. Built for brands that move fast.

---

## Short Description (140 chars)
Bold, editorial OS 2.0 theme — oversized type, full-bleed imagery, mega-menu, lookbook hotspots, and AJAX cart for fashion-forward DTC brands.

---

## Full Description

**Momentum** is a premium Shopify Online Store 2.0 theme built for brands that lead with identity. Inspired by the visual language of Supreme, Bottega Veneta, and Palace — it's designed for streetwear, fashion, and lifestyle brands that want their online store to feel like a flagship, not a template.

### Design

- **Oversized fluid display type** — fluid headlines from 3.5rem to 9rem using `clamp()`. Every page opens with a statement.
- **Dark editorial palette** — deep zinc backgrounds, high-contrast white text, and Klyna violet (#7c5cff) accents. Configure your own colors in the theme editor.
- **Full-bleed everything** — hero banners, collection pages, and split-hero sections all stretch edge-to-edge with dramatic image crops.
- **Asymmetric grid** — intentionally offset layouts that feel editorial rather than gridded.
- **Hover reveals** — product cards show quick-add buttons on hover with smooth upward reveal animations.

### Commerce

- **Mega menu** — nested collection navigation with up to three levels, perfect for large catalogs.
- **Lookbook with hotspots** — tag products directly on editorial imagery. Click a hotspot to see a quick-view panel.
- **Slide-in cart drawer** — AJAX cart with real-time count, quantity controls, and direct checkout.
- **AJAX filters + sort** — collection pages filter and sort without a full page reload. URL updates for shareability.
- **Complementary products** — powered by Shopify's product recommendations API.
- **Variant swatches** — color options show as circular swatches; sizes and other options as button pickers.
- **Sticky buy bar** — a persistent add-to-cart bar appears as users scroll past the main buy button.

### Performance

- Deferred JS loading (all scripts use `defer`).
- Responsive images with `srcset` and `sizes` on every `image_tag`.
- CSS-only parallax on hero banners (no library).
- Print-media CSS loading trick to avoid render-blocking stylesheets.
- Font-display: swap on all custom fonts.

### Accessibility

- Skip-to-content link.
- Full keyboard navigation for mega menu and mobile drawer (focus trap, Escape key).
- ARIA attributes throughout (`aria-expanded`, `aria-hidden`, `aria-label`, `role`).
- Semantic HTML5 (`nav`, `main`, `article`, `aside`, `header`, `footer`).

---

## Target Merchant Profile

**Perfect for:**
- Streetwear and sneaker brands (Supreme, Palace, Kith energy)
- High-fashion and contemporary DTC labels
- Lifestyle brands with strong visual identity
- Brands with large product catalogs needing mega-menu navigation
- Editorial-focused brands doing lookbook and campaign storytelling
- Any DTC brand wanting a premium dark-mode aesthetic

**Industries:**
Apparel & Clothing, Shoes & Footwear, Accessories, Lifestyle, Activewear, Luxury Goods

---

## Keywords

shopify theme, editorial theme, dark theme, fashion theme, streetwear theme, mega menu, lookbook, product quickview, ajax cart, DTC, bold typography, full bleed, OS 2.0, momentum, klyna, dark mode shopify, fashion shopify theme, premium shopify theme

---

## Theme Features Checklist

- [x] Online Store 2.0 (JSON templates + sections everywhere)
- [x] Mega menu
- [x] Cart drawer (AJAX)
- [x] Predictive search
- [x] Product quick-view
- [x] Color swatches
- [x] AJAX filtering
- [x] Product media gallery + lightbox
- [x] Lookbook with product hotspots
- [x] Newsletter signup
- [x] Social media icons
- [x] Blog
- [x] Full customer account area
- [x] Product recommendations
- [x] Sticky buy bar
- [x] Responsive images
- [x] Structured data (JSON-LD)
- [x] OG / Twitter Card meta tags
- [x] Accessibility (WCAG 2.1 AA target)
- [x] Mobile-first responsive design
- [x] Font picker (heading + body)
- [x] Color customizer
- [x] Dark + light palette support

---

## Support

**Developer:** Klyna (https://klyna.dev)
**Support:** https://klyna.dev/support
**Documentation:** https://klyna.dev/themes/momentum/docs
